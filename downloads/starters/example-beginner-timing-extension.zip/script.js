"use strict";

const canvas = document.querySelector("#game-canvas");
const ctx = canvas.getContext("2d");

let markerX, speed, state, success;

function start() {
  markerX = 80;
  speed = 4;
  state = "moving";
  success = false;
}

function update() {
  if (state === "moving") {
    markerX += speed;
    if (markerX >= 720 || markerX <= 80) {
      speed = -speed;
    }
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#d9e8f9";
  ctx.fillRect(80, 200, 640, 24);
  ctx.fillStyle = "#50a76b";
  ctx.fillRect(300, 200, 200, 24);
  ctx.fillStyle = "#204a84";
  ctx.fillRect(markerX - 5, 180, 10, 64);
  ctx.fillStyle = "#26334a";
  ctx.font = "24px sans-serif";
  ctx.fillText("スペースで止める", 270, 120);
  if (state === "stopped") {
    if (success) {
      ctx.fillText("成功！ 緑の中で止まった", 220, 300);
    } else {
      ctx.fillText("おしい！ 緑の外で止まった", 205, 300);
    }
    ctx.fillText("R キーでもう一度", 260, 350);
  }
}

window.addEventListener("keydown", (event) => {
  if (event.repeat || event.ctrlKey || event.altKey || event.metaKey || event.isComposing) return;
  if (event.code === "Space") {
    event.preventDefault();
    if (state === "moving") {
      state = "stopped";
      success = markerX >= 300 && markerX <= 500;
    }
  } else if (event.key.toLowerCase() === "r" && state === "stopped") {
    start();
  }
});

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

start();
gameLoop();
