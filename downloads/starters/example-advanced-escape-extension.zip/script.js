"use strict";

const canvas = document.querySelector("#game-canvas");
const ctx = canvas.getContext("2d");

class RoomObject {
  constructor(x, y, width, height, name) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.name = name;
  }

  contains(x, y) {
    return x >= this.x && x < this.x + this.width &&
      y >= this.y && y < this.y + this.height;
  }

  draw() {
    ctx.fillStyle = "#b7cbd4";
    ctx.fillRect(this.x, this.y, this.width, this.height);
    ctx.fillStyle = "#24354a";
    ctx.font = "22px sans-serif";
    ctx.fillText(this.name, this.x + 15, this.y + 35);
  }
}

class Inventory {
  constructor() {
    this.items = [];
    this.selected = "";
  }

  add(item) {
    if (!this.items.includes(item)) this.items.push(item);
  }

  click(x, y) {
    for (let i = 0; i < this.items.length; i++) {
      const left = 30 + i * 150;
      if (x >= left && x < left + 140 && y >= 390 && y < 435) {
        this.selected = this.items[i];
        return true;
      }
    }
    return false;
  }

  draw() {
    for (let i = 0; i < this.items.length; i++) {
      const left = 30 + i * 150;
      ctx.fillStyle = "#f8dc8b";
      ctx.fillRect(left, 390, 140, 45);
      if (this.items[i] === this.selected) {
        ctx.strokeStyle = "#c45631";
        ctx.lineWidth = 4;
        ctx.strokeRect(left, 390, 140, 45);
      }
      ctx.fillStyle = "#24354a";
      ctx.font = "17px sans-serif";
      ctx.fillText(this.items[i], left + 8, 418);
    }
  }
}

class Game {
  constructor() {
    this.objects = [
      new RoomObject(60, 105, 160, 180, "本棚"),
      new RoomObject(300, 130, 170, 140, "引き出し"),
      new RoomObject(535, 120, 165, 150, "換気口"),
      new RoomObject(625, 285, 120, 80, "扉")
    ];
    this.inventory = new Inventory();
    this.message = "気になる物をクリックしよう";
    this.view = "room";
    this.digits = [0, 0, 0];
    this.unlocked = false;
    this.ventOpen = false;
    this.state = "playing";
  }

  clickDrawer(x, y) {
    if (x >= 30 && x < 150 && y >= 390 && y < 435) {
      this.view = "room";
      this.message = "部屋に戻った";
      return;
    }
    for (let i = 0; i < this.digits.length; i++) {
      const left = 250 + i * 90;
      if (x >= left && x < left + 70 && y >= 190 && y < 270) {
        this.digits[i] = (this.digits[i] + 1) % 10;
        return;
      }
    }
    if (x >= 300 && x < 500 && y >= 300 && y < 345) {
      if (this.digits.join("") === "241") {
        this.unlocked = true;
        this.inventory.add("ドライバー");
        this.message = "ドライバーを手に入れた";
      } else {
        this.message = "番号が違うようだ";
      }
    }
  }

  click(x, y) {
    if (this.state !== "playing") return;
    if (this.view === "drawer") {
      this.clickDrawer(x, y);
      return;
    }
    if (this.inventory.click(x, y)) {
      this.message = this.inventory.selected + "を選んだ";
      return;
    }
    for (const object of this.objects) {
      if (!object.contains(x, y)) continue;
      if (object.name === "本棚") this.message = "メモに 241 と書いてある";
      else if (object.name === "引き出し") {
        this.view = "drawer";
        this.message = "3けたの番号を合わせよう";
      } else if (object.name === "換気口") {
        if (this.inventory.selected === "ドライバー") {
          this.ventOpen = true;
          this.inventory.add("鍵");
          this.message = "換気口を開けて鍵を見つけた";
        } else this.message = "換気口はドライバーで開きそう";
      } else if (object.name === "扉") {
        if (this.inventory.selected === "鍵") {
          this.state = "clear";
          this.message = "脱出成功！ R でもう一度";
        } else this.message = "扉には鍵が必要だ";
      }
      return;
    }
  }

  draw() {
    ctx.fillStyle = "#24354a";
    ctx.font = "22px sans-serif";
    if (this.view === "drawer") {
      ctx.fillText("数字をクリックして番号を合わせよう", 165, 120);
      for (let i = 0; i < this.digits.length; i++) {
        ctx.fillStyle = "#f8dc8b";
        ctx.fillRect(250 + i * 90, 190, 70, 80);
        ctx.fillStyle = "#24354a";
        ctx.fillText(String(this.digits[i]), 275 + i * 90, 240);
      }
      ctx.fillStyle = "#b7cbd4";
      ctx.fillRect(300, 300, 200, 45);
      ctx.fillStyle = "#24354a";
      ctx.fillText("番号を確かめる", 315, 330);
      ctx.fillStyle = "#b7cbd4";
      ctx.fillRect(30, 390, 120, 45);
      ctx.fillStyle = "#24354a";
      ctx.fillText("戻る", 52, 420);
    } else {
      ctx.fillText("部屋の物をクリックして調べよう", 45, 45);
      for (const object of this.objects) {
        object.draw();
        if ((object.name === "引き出し" && this.unlocked) ||
            (object.name === "換気口" && this.ventOpen)) {
          ctx.fillStyle = "#416a47";
          ctx.fillRect(object.x, object.y + 60, object.width, 35);
          ctx.fillStyle = "#ffffff";
          ctx.font = "18px sans-serif";
          ctx.fillText("開いた", object.x + 15, object.y + 84);
        }
      }
      this.inventory.draw();
    }
    ctx.fillStyle = "#24354a";
    ctx.font = "20px sans-serif";
    ctx.fillText(this.message, 45, 370);
  }
}

let game;

function start() {
  game = new Game();
}

function update() {
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  game.draw();
}

function pointFromClick(event) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: (event.clientX - rect.left) * canvas.width / rect.width,
    y: (event.clientY - rect.top) * canvas.height / rect.height
  };
}

canvas.addEventListener("click", (event) => {
  const point = pointFromClick(event);
  game.click(point.x, point.y);
});

window.addEventListener("keydown", (event) => {
  if (!event.repeat && event.key.toLowerCase() === "r") start();
});

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

start();
gameLoop();
